declare module 'hemera-jaeger';
