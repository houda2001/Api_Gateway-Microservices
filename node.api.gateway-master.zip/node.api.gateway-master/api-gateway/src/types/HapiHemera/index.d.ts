declare module 'hapi-hemera';
