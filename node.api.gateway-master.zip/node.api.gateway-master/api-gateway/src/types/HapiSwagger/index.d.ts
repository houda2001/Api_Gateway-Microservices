declare module 'hapi-swagger';
