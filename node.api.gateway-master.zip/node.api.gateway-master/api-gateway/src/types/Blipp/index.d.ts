declare module 'blipp';
