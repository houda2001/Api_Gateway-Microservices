declare module 'hemera-redis-cache';
