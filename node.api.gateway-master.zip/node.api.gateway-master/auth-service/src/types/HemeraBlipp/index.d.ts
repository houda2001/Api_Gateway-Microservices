declare module 'hemera-blipp';
