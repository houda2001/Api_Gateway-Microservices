declare module 'hemera-joi';
