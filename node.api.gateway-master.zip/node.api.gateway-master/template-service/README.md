# Template Service

This is template for creating new services. Simply copy and paste the root directory, rename the folder, and customise as required.
