# Registration Service

This microservice is used all registration events that occur on the front-end, e.g. early sign-up, user contact form, registration, etc.
