export default interface IRecaptchaRequest {
	secret: string;
	response: string;
}
